package com.cushion.trainer

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebSettings
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)
        val ws: WebSettings = webView.settings
        ws.javaScriptEnabled = true
        ws.allowFileAccess = true
        ws.domStorageEnabled = true
        // load local asset (index.html)
        webView.loadUrl("file:///android_asset/index.html")
    }
}
